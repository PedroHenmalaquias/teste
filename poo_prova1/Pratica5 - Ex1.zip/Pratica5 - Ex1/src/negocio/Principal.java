package negocio;

import dados.*;

public class Principal {
	
	public static void main(String[] args) {
		Sistema sistema = new Sistema();
		
		ContaCorrente cc = new ContaCorrente("100101", 100);
		sistema.cadastrarConta(cc);
		
		ContaSalario cs = new ContaSalario("200101", 200,"922939239");
		sistema.cadastrarConta(cs);

		sistema.realizarDeposito(cc, 300);
		
		System.out.println(sistema.obterExtrato(cc));
	}

}
