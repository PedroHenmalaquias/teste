package negocio;

import dados.*;
import java.util.List;
import java.util.ArrayList;

public class Sistema {
	
	private List<ContaBancaria> contas = new ArrayList<ContaBancaria>();
	
	public void cadastrarConta(ContaBancaria conta) {
		contas.add(conta);
	}

	public void realizarSaque(ContaBancaria conta, float valor) {
		conta.sacar(valor);
	}
	
	public boolean realizarDeposito(ContaCorrente conta, float valor) {
		return conta.depositar(valor);
	}

	public boolean realizarDeposito(ContaSalario conta, float valor, String cnpj) {
		return conta.depositar(valor,cnpj);
	}

	public List<ContaBancaria> getContas(){
		return contas;
	}
	
	public List<ContaCorrente> getContasCorrentes(){
		List<ContaCorrente> cc = new ArrayList<ContaCorrente>();
		
		for(ContaBancaria c : contas) {
			if(c instanceof ContaCorrente) {
				cc.add((ContaCorrente)c);
			}
		}
		return cc;
	}
	
	public List<ContaSalario> getContasSalario(){
		List<ContaSalario> cs = new ArrayList<ContaSalario>();
		
		for(ContaBancaria c : contas) {
			if(c instanceof ContaSalario) {
				cs.add((ContaSalario)c);
			}
		}
		return cs;
	}
	
	public String obterExtrato(ContaBancaria c) {
		return c.gerarExtrato();
	}
	
}
