package dados;

public class ContaBancaria {
	protected String cpf;
	protected float saldo;
	
	public ContaBancaria() {
		
	}
	
	public ContaBancaria(String cpf, float saldo) {
		this.cpf = cpf;
		this.saldo = saldo;
	}
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public float getSaldo() {
		return saldo;
	}
	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}
	
	public String toString() {
		return "CPF: "+ cpf+ "- Saldo: "+ saldo;
	}
	
	public float sacar(float valor) {
		if(saldo >= valor) {
			saldo -= valor;
			return valor;
		}
		return 0;
	}
	
	public String gerarExtrato() {
		return toString();
	}

}
