package apresentacao;

import dados.Cidade;
import dados.Cliente;
import dados.Reserva;
import negocio.ReservaPassagem;

import java.util.Scanner;

public class Principal {

    private ReservaPassagem reservaPassagem = new ReservaPassagem();
    private Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {
        Principal p = new Principal();
        int opcao = -1;
        while (opcao != 0) {
            opcao = p.menu();
            switch (opcao) {
                case 0:
                    System.out.println("Encerrando...");
                    break;
                case 1:
                    p.cadastrarCliente();
                    break;
                case 2:
                    p.cadastrarCidade();
                    break;
                case 3:
                    p.fazerReserva();
                    break;
                case 4:
                    p.mostrarReservas();
                    break;
                default:
                    System.out.println("Opcao invalida!");
            }
        }
    }

    private int menu() {
        System.out.println("\nInsira o valor do que deseja fazer:");
        System.out.println("1- Cadastrar cliente");
        System.out.println("2- Cadastrar cidade");
        System.out.println("3- Fazer reserva");
        System.out.println("4- Mostrar reservas");
        System.out.println("0- Sair");
        return lerInt("> ");
    }

    public void cadastrarCliente() {
        int cpf = lerInt("CPF: ");
        if (buscarCliente(cpf) != null) {
            System.out.println("Ja existe um cliente com esse CPF.");
            return;
        }
        Cliente c = new Cliente();
        c.setCpf(cpf);
        c.setNome(lerTexto("Nome: "));
        c.setEndereco(lerTexto("Endereco: "));
        c.setTelefone(lerTexto("Telefone: "));
        reservaPassagem.cadastrarCliente(c);
        System.out.println("Cliente cadastrado!");
    }

    public void cadastrarCidade() {
        Cidade cidade = new Cidade();
        cidade.setNome(lerTexto("Nome da cidade: "));
        cidade.setEstado(lerTexto("Estado: "));
        reservaPassagem.cadastrarCidade(cidade);
        System.out.println("Cidade cadastrada!");
    }

    public void fazerReserva() {
        Cliente cliente = buscarCliente(lerInt("CPF do cliente: "));
        if (cliente == null) {
            System.out.println("Cliente nao encontrado.");
            return;
        }

        Cidade[] cidades = reservaPassagem.mostrarCidades();
        if (cidades.length < 2) {
            System.out.println("Cadastre pelo menos 2 cidades antes de reservar.");
            return;
        }
        for (int i = 0; i < cidades.length; i++) {
            System.out.println((i + 1) + "- " + cidades[i].getNome() + "/" + cidades[i].getEstado());
        }
        Cidade origem = cidades[escolher("Origem: ", cidades.length)];
        Cidade destino;
        do {
            destino = cidades[escolher("Destino: ", cidades.length)];
            if (destino == origem) {
                System.out.println("Destino deve ser diferente da origem.");
            }
        } while (destino == origem);

        System.out.println("--- Voo de ida ---");
        Reserva ida = lerReserva(origem, destino);
        ida.setClasseVoo(lerTexto("Classe do voo: "));

        boolean idaEVolta = lerTexto("Ida e volta? (s/n): ").equalsIgnoreCase("s");
        if (idaEVolta) {
            System.out.println("--- Voo de volta ---");
            Reserva volta = lerReserva(destino, origem);
            volta.setClasseVoo(ida.getClasseVoo());
            reservaPassagem.reservarVolta(cliente, ida, volta);
        } else {
            reservaPassagem.reservarIda(cliente, ida);
        }
        System.out.println("Reserva realizada!");
    }

    public void mostrarReservas() {
        int cpf = lerInt("CPF do cliente: ");
        if (buscarCliente(cpf) == null) {
            System.out.println("Cliente nao encontrado.");
            return;
        }
        Reserva[] reservas = reservaPassagem.mostrarReservas(cpf);
        if (reservas.length == 0) {
            System.out.println("Nenhuma reserva para este cliente.");
            return;
        }
        for (Reserva r : reservas) {
            System.out.println(r);
        }
    }

    // ---------- auxiliares (entrada de dados) ----------

    private Reserva lerReserva(Cidade origem, Cidade destino) {
        Reserva r = new Reserva();
        r.setOrigem(origem);
        r.setDestino(destino);
        r.setNumReserva(lerInt("Numero da reserva: "));
        r.setDataVoo(lerTexto("Data do voo: "));
        r.setHoraVoo(lerTexto("Hora do voo: "));
        r.setPreco(lerFloat("Preco: "));
        r.setPoltrona(lerInt("Poltrona: "));
        return r;
    }

    private Cliente buscarCliente(int cpf) {
        for (Cliente c : reservaPassagem.mostrarClientes()) {
            if (c.getCpf() == cpf) {
                return c;
            }
        }
        return null;
    }

    private int escolher(String msg, int tamanho) {
        int n;
        do {
            n = lerInt(msg);
        } while (n < 1 || n > tamanho);
        return n - 1;
    }

    private String lerTexto(String msg) {
        System.out.print(msg);
        return entrada.nextLine().trim();
    }

    private int lerInt(String msg) {
        while (true) {
            try {
                return Integer.parseInt(lerTexto(msg));
            } catch (NumberFormatException e) {
                System.out.println("Valor invalido, digite um numero inteiro.");
            }
        }
    }

    private float lerFloat(String msg) {
        while (true) {
            try {
                return Float.parseFloat(lerTexto(msg).replace(',', '.'));
            } catch (NumberFormatException e) {
                System.out.println("Valor invalido, digite um numero.");
            }
        }
    }
}
