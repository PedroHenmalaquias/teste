package dados;

public class Cliente {

    private int cpf;
    private String nome;
    private String endereco;
    private String telefone;
    private Reserva[] reservas;

    public Cliente() {
        reservas = new Reserva[100];
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Reserva[] getReservas() {
        return reservas;
    }

    public void setReservas(Reserva[] reservas) {
        this.reservas = reservas;
    }

    public void reservarIda(Reserva reserva) {
        adicionar(reserva);
    }

    public void reservarVolta(Reserva ida, Reserva volta) {
        ida.setVolta(volta);
        ida.setIdaEVolta(true);
        adicionar(volta);
    }

    private void adicionar(Reserva reserva) {
        for (int i = 0; i < reservas.length; i++) {
            if (reservas[i] == null) {
                reservas[i] = reserva;
                return;
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Reserva r : reservas) {
            if (r != null) {
                sb.append("\n  ").append(r);
            }
        }
        return "Cliente{" +
                "cpf=" + cpf +
                ", nome='" + nome + '\'' +
                ", endereco='" + endereco + '\'' +
                ", telefone='" + telefone + '\'' +
                ", reservas=[" + sb + "]" +
                '}';
    }
}
