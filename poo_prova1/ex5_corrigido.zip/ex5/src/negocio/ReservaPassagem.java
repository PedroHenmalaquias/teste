package negocio;

import dados.Cidade;
import dados.Cliente;
import dados.Reserva;

import java.util.Arrays;
import java.util.Objects;

public class ReservaPassagem {

    private Cidade[] listaDeCidades = new Cidade[100];
    private Cliente[] listaDeClientes = new Cliente[100];

    public void cadastrarCidade(Cidade cidade) {
        for (int i = 0; i < listaDeCidades.length; i++) {
            if (listaDeCidades[i] == null) {
                listaDeCidades[i] = cidade;
                return;
            }
        }
    }

    public void cadastrarCliente(Cliente cliente) {
        for (int i = 0; i < listaDeClientes.length; i++) {
            if (listaDeClientes[i] == null) {
                listaDeClientes[i] = cliente;
                return;
            }
        }
    }

    public void reservarIda(Cliente cliente, Reserva reserva) {
        cliente.reservarIda(reserva);
    }

    public void reservarVolta(Cliente cliente, Reserva ida, Reserva volta) {
        cliente.reservarIda(ida);
        cliente.reservarVolta(ida, volta);
    }

    // Retorna um array vazio se o cliente não existir ou não tiver reservas.
    public Reserva[] mostrarReservas(int cpfCliente) {
        for (Cliente c : listaDeClientes) {
            if (c != null && c.getCpf() == cpfCliente) {
                return Arrays.stream(c.getReservas())
                        .filter(Objects::nonNull)
                        .toArray(Reserva[]::new);
            }
        }
        return new Reserva[0];
    }

    public Cliente[] mostrarClientes() {
        return Arrays.stream(listaDeClientes)
                .filter(Objects::nonNull)
                .toArray(Cliente[]::new);
    }

    public Cidade[] mostrarCidades() {
        return Arrays.stream(listaDeCidades)
                .filter(Objects::nonNull)
                .toArray(Cidade[]::new);
    }
}
