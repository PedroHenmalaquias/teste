import dados.*;

/** Teste rápido (o enunciado não exige): demonstra POLIMORFISMO com um vetor de Gerador. */
public class Main {
    public static void main(String[] args) {
        Gerador[] geradores = {
            new Naturais(), new Abundantes(), new Fibonacci(), new Fatoriais(),
            new NumeroPrimos(), new Quadrados(), new Perfeitos()
        };
        int[] quantidades = {10, 10, 10, 10, 10, 10, 4};

        for (int i = 0; i < geradores.length; i++) {
            geradores[i].gerar(quantidades[i]);   // cada objeto executa SEU gerar()
            System.out.println(geradores[i].getClass().getSimpleName()
                + ": " + geradores[i].getSequencia());
        }
    }
}
