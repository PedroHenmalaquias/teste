package dados;

/**
 * Números abundantes: a soma dos divisores próprios é MAIOR que o número.
 * Ex.: 12 (1+2+3+4+6 = 16), 18, 20, 24...
 * 'quantidade' = quantos abundantes gerar (os 'quantidade' primeiros).
 */
public class Abundantes extends Gerador {

    @Override
    public void gerar(int quantidade) {
        validar(quantidade);
        limpar();
        int encontrados = 0;
        int candidato = 1;
        while (encontrados < quantidade) {
            if (somaDivisoresProprios(candidato) > candidato) {
                adicionar(candidato);
                encontrados++;
            }
            candidato++;
        }
    }
}
