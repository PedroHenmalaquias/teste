package dados;

/** Fatoriais: 1!, 2!, 3!... = 1, 2, 6, 24, 120... */
public class Fatoriais extends Gerador {

    @Override
    public void gerar(int quantidade) {
        validar(quantidade);
        limpar();
        int fatorial = 1;
        for (int i = 1; i <= quantidade; i++) {
            // Reaproveita o anterior: i! = i * (i-1)!
            // multiplyExact lança ArithmeticException se passar do limite do int (13! já estoura).
            fatorial = Math.multiplyExact(fatorial, i);
            adicionar(fatorial);
        }
    }
}
