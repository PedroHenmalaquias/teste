package dados;

/**
 * Quadrados perfeitos: 1, 4, 9, 16, 25...
 * (No slide aparece "2" na lista, mas 2 não tem raiz inteira — é erro de digitação.)
 */
public class Quadrados extends Gerador {

    @Override
    public void gerar(int quantidade) {
        validar(quantidade);
        limpar();
        for (int i = 1; i <= quantidade; i++) {
            adicionar(Math.multiplyExact(i, i)); // o k-ésimo quadrado é k*k
        }
    }
}
