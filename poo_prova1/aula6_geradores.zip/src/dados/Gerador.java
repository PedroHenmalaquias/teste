package dados;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe ABSTRATA: não pode ser instanciada (new Gerador() não compila).
 * Define o "contrato" que toda sequência deve seguir: o método gerar().
 */
public abstract class Gerador {

    // Atributo privado (encapsulamento), como no diagrama UML.
    private List<Integer> sequencia;

    public Gerador() {
        this.sequencia = new ArrayList<>();
    }

    /**
     * Método ABSTRATO: sem corpo. Cada subclasse é OBRIGADA a implementá-lo,
     * gerando a sua própria sequência com 'quantidade' elementos.
     */
    public abstract void gerar(int quantidade);

    public List<Integer> getSequencia() {
        return this.sequencia;
    }

    // ---- Auxiliares protegidos: só as subclasses enxergam ----
    // Como 'sequencia' é private, as filhas precisam de um meio de alterá-la.

    /** Adiciona um número à sequência. */
    protected void adicionar(int valor) {
        this.sequencia.add(valor);
    }

    /** Limpa a sequência; chamado no início de cada gerar() para não acumular chamadas antigas. */
    protected void limpar() {
        this.sequencia.clear();
    }

    /** Valida o parâmetro de todas as subclasses em um só lugar. */
    protected void validar(int quantidade) {
        if (quantidade < 0) {
            throw new IllegalArgumentException("A quantidade não pode ser negativa.");
        }
    }

    /**
     * Soma dos divisores PRÓPRIOS de n (todos os divisores, exceto o próprio n).
     * Usada por Abundantes e Perfeitos. Percorre só até a raiz quadrada de n:
     * cada divisor i encontrado tem um "par" n/i.
     */
    protected static int somaDivisoresProprios(int n) {
        if (n <= 1) return 0;
        int soma = 1; // 1 divide todo n > 1
        for (int i = 2; (long) i * i <= n; i++) {
            if (n % i == 0) {
                soma += i;
                if (i != n / i) soma += n / i; // evita somar duas vezes em quadrados (ex.: 6*6)
            }
        }
        return soma;
    }
}
