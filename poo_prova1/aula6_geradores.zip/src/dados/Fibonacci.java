package dados;

/** Fibonacci: 0, 1, 1, 2, 3, 5, 8... com F(n) = F(n-1) + F(n-2). */
public class Fibonacci extends Gerador {

    @Override
    public void gerar(int quantidade) {
        validar(quantidade);
        limpar();
        int anterior = 0; // F(n-2)
        int atual = 1;    // F(n-1)
        for (int i = 0; i < quantidade; i++) {
            adicionar(anterior);
            // addExact lança ArithmeticException em vez de estourar o int silenciosamente
            int proximo = Math.addExact(anterior, atual);
            anterior = atual;
            atual = proximo;
        }
    }
}
