package dados;

/**
 * Números perfeitos: soma dos divisores próprios == o próprio número.
 * 6 (1+2+3), 28 (1+2+4+7+14), 496, 8128, 33550336...
 */
public class Perfeitos extends Gerador {

    // Só 5 perfeitos cabem em int; o 6º (8589869056) é maior que Integer.MAX_VALUE.
    private static final int MAXIMO_EM_INT = 5;

    @Override
    public void gerar(int quantidade) {
        validar(quantidade);
        if (quantidade > MAXIMO_EM_INT) {
            throw new IllegalArgumentException(
                "Apenas os " + MAXIMO_EM_INT + " primeiros perfeitos cabem em int.");
        }
        limpar();
        int encontrados = 0;
        int candidato = 2;
        while (encontrados < quantidade) {
            if (somaDivisoresProprios(candidato) == candidato) {
                adicionar(candidato);
                encontrados++;
            }
            candidato++;
        }
    }
}
