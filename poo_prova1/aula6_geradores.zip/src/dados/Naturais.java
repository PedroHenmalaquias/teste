package dados;

/** Números naturais positivos: 1, 2, 3, ..., n. */
public class Naturais extends Gerador {

    @Override
    public void gerar(int quantidade) {
        validar(quantidade);
        limpar();
        for (int i = 1; i <= quantidade; i++) {
            adicionar(i);
        }
    }
}
