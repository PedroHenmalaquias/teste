package dados;

/** Números primos: 2, 3, 5, 7, 11... (divisíveis só por 1 e por eles mesmos). */
public class NumeroPrimos extends Gerador {

    @Override
    public void gerar(int quantidade) {
        validar(quantidade);
        limpar();
        int encontrados = 0;
        int candidato = 2; // 1 não é primo
        while (encontrados < quantidade) {
            if (ehPrimo(candidato)) {
                adicionar(candidato);
                encontrados++;
            }
            candidato++;
        }
    }

    /** Testa divisores só até a raiz quadrada: se n tem divisor maior, tem também um menor. */
    private boolean ehPrimo(int n) {
        if (n < 2) return false;
        for (int i = 2; (long) i * i <= n; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
}
