POO - Aula Prática 6 - Classes Abstratas (Gerador de sequências)

Estrutura:
  src/dados/Gerador.java       classe abstrata (contrato)
  src/dados/*.java             7 subclasses, uma por sequência
  src/Main.java                teste opcional (polimorfismo)

Compilar e rodar (dentro de src/):
  mkdir out
  javac -d out dados/*.java Main.java
  java -cp out Main
